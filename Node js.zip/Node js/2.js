var http = require('http');
// console.log(http);

const server = http.createServer(function (req, res) {
    console.log(typeof req, typeof res,);
    res.end("hello world!");
});
server.listen(9000);