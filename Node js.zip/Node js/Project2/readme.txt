use productDetails
show dbs
db
db.createCollection("products")
show collections

db.products.insert([{ "name" : "T-shirt", "price":500, "discount":40},
{ "name" : "Watch", "price":1000, "discount":50},
{ "name" : "Handbag", "price":200, "discount":20}]);
